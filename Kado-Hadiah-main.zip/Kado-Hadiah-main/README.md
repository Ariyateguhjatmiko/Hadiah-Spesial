Ini untuk belajar saja 😁🙏
